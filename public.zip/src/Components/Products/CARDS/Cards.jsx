import Card from 'react-bootstrap/Card';
import './Cards.css';

function GroupExample() {
  return (
    <>
    
    

   

     

      <div className='card2'>
      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://cdn.xingosoftware.com/audioxpress/images/fetch/dpr_1/https://www.audioxpress.com/assets/upload/images/1/20210115143110_Galaxy-Buds-Pro-FrontWeb.jpg" />
      <Card.Body>
        <Card.Title>earbuds</Card.Title>
      </Card.Body>
    </Card>



      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="" />
      <Card.Body>
        <Card.Title>Men Regular shirt</Card.Title> 
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://cdn.shopify.com/s/files/1/1007/6022/products/nmt_mn_shrt_fln_csl_P25C14_BLGN_img1.jpg?v=1590799826" />
      <Card.Body>
        <Card.Title>shecke shirt</Card.Title>
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.s4_O660Vah0Hx-Z_6Zct0wAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Men shoe</Card.Title>
      </Card.Body>
    </Card>


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.e4HPwRf2PrIi8n27w2ETTAHaHa?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Vivo Y16 Mobile</Card.Title>
      </Card.Body>
    </Card>
      </div>
    



      <div className='card2'>
      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.spn8bmtaB3r7LH04OsvX3gAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Apple Watch</Card.Title>
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.YB-jR8yGectHcOPdJCValQAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Handbags For Women</Card.Title> 
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src='https://th.bing.com/th/id/OIP.wFCwAoVcwR62zN1RXHrnJgHaE5?rs=1&pid=ImgDetMain' />
      <Card.Body>
        <Card.Title>asus-14-0-laptop</Card.Title>   
      </Card.Body>
    </Card>


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://cdn.xingosoftware.com/audioxpress/images/fetch/dpr_1/https://www.audioxpress.com/assets/upload/images/1/20210115143110_Galaxy-Buds-Pro-FrontWeb.jpg" />
      <Card.Body>
        <Card.Title>earbuds</Card.Title>
      </Card.Body>
    </Card>


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://cdn.xingosoftware.com/audioxpress/images/fetch/dpr_1/https://www.audioxpress.com/assets/upload/images/1/20210115143110_Galaxy-Buds-Pro-FrontWeb.jpg" />
      <Card.Body>
        <Card.Title>earbuds</Card.Title>
      </Card.Body>
    </Card>
      </div>
    
    

    




    
    
    </>
  );
}

export default GroupExample;