import './Cards.css';
import { LinkContainer } from 'react-router-bootstrap';
import BasicRating from '../../Ratting';
import { Card,Spinner, } from 'react-bootstrap';
import React, { useState, useEffect } from 'react';
import CheckIcon from '@mui/material/Alert';
import Alert from '@mui/material/Alert';




function Cards3() {

  const [products, setProducts] = useState([]);
  const [loading,setLoading] =useState([true]);
  const [showMessage, setShowMessage] = useState(false);

  useEffect(() => {
    fetch('https://api.escuelajs.co/api/v1/products')
   
    
      .then(response => response.json())
      .then(data => {setProducts(data); console.log(data)
        setLoading(false)
      })
      .catch(()=>setLoading(false))
      .catch(error => console.error('Error fetching data:', error));
  }, []);
  const addcart = (product) => {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({
        name: product.title,
        images: product.image,
        price: product.price
    });
    localStorage.setItem('cart', JSON.stringify(cart));

    // Show the "Add to cart successfully" message
    setShowMessage(true);

    // Temporarily remove this to check if the message shows up
     setTimeout(() => {
         setShowMessage(false);
     }, 3000);
};



  
  return (
    <>
    {showMessage && (
               <Alert className='cart-alert' icon={<CheckIcon fontSize="inherit" />} severity="success">
              successfully   Add to cart
             </Alert>
    )}
<div className="section3">
     
     <h3>Best Deals of the day</h3>
     
     <div className='card0'>
    
        {loading ? (
                    <div className="spinner-container">
                        <Spinner animation="border" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </Spinner>
                    </div>
                ) :
        products.map(product => (
         <Card key={product.id} style={{ width:  '18rem'}}>
         <Card.Img variant="top" src={product.images} alt={product.title} />
         <Card.Body>
           <Card.Title>{product.title}</Card.Title>
           <p>From ${product.price}</p>
           <BasicRating/>
          <button className='btn1' onClick={() => addcart(product)}>Add to Cart</button>

      <button className='btn2'>Buy Now</button>
         </Card.Body>
       </Card>
        ))}
    
 

    </div>
    </div>
   


  <div className='section3'>
       <h3>Top deals</h3>
       <div className='card2'>
      
      


      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://cdn.onecrazyhouse.com/wp-content/uploads/2016/03/best-electronic-gadgets-4.jpg" />
      <Card.Body>
        <LinkContainer to="/Eloctronics"><Card.Title>Eloctronics</Card.Title></LinkContainer>
       
      </Card.Body>
    </Card>

      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.rHyHufgDrUXEBonuXZ9nmQHaGP?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Gadget</Card.Title> 
       
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.lchXW73xdebHK6qOJOdTrAHaE8?w=800&h=534&rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Rakhi special</Card.Title>
      </Card.Body>
    </Card>


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.U1C2eN5YAuNy-vSfOi_8iQAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Fashion</Card.Title>
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.bHGYc7qodZ5ECP2Ms-mJgQHaEx?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Home essentials</Card.Title>
      </Card.Body>
    </Card>



   


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.sqr0SJvvbWScaVq2qk5CFQHaF9?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Furniture</Card.Title>
      </Card.Body>
      </Card>
    

      
      
    </div>
     
   </div>
   
    
    
    </>
  );
}

export default Cards3;