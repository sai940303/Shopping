
import './Cards.css';
import { LinkContainer } from 'react-router-bootstrap';
import BasicRating from '../../Ratting';
import { Card } from 'react-bootstrap';
import React, { useState, useEffect } from 'react';
import Api2 from '../../Api/Api2';






function Cards2() {

  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('https://api.escuelajs.co/api/v1/products')
      .then(response => response.json())
      .then(data => setProducts(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  
  return (
    <>
  <div className='section3'>
       <h3>Top deals</h3>

      <div className='card0'>
      


      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.RGhXRX912xVSfSUMgHxbuQAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Accessories</Card.Title>
       
      </Card.Body>
    </Card>

      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.rHyHufgDrUXEBonuXZ9nmQHaGP?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Gadget</Card.Title> 
       
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.lchXW73xdebHK6qOJOdTrAHaE8?w=800&h=534&rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Rakhi special</Card.Title>
      </Card.Body>
    </Card>


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.U1C2eN5YAuNy-vSfOi_8iQAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Fashion</Card.Title>
      </Card.Body>
    </Card>



    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.bHGYc7qodZ5ECP2Ms-mJgQHaEx?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Home essentials</Card.Title>
      </Card.Body>
    </Card>



   


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.sqr0SJvvbWScaVq2qk5CFQHaF9?rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Furniture</Card.Title>
      </Card.Body>
      </Card>
    

      {products.map(product => (
     

     <Card className='tag' key={product.id} style={{ width: '18rem' }}>
       <Card.Img variant="top" src={product.images[0]} />
       <Card.Body>
         <LinkContainer to={`/product/${product.id}`}>
           <Card.Title>{product.title}</Card.Title>
         </LinkContainer>
         <p>From ${product.price}</p>
        <BasicRating/>
       </Card.Body>
     </Card>
    
   ))}
      
    </div>
     
   </div>
   
    

   
     <div className="section3">
     
       <h3>Best Deals on Smartphone</h3>
       
      <div className='card2'>
      

      <Card style={{ width: '18rem' }}>
      
      <Card.Img variant="top" src="https://tunisiatech.tn/8882-large_default/smartphone-oppo-a17-4go-64go.jpg" />
      <Card.Body>
        <LinkContainer to="/oppo A17"><Card.Title>oppo A17</Card.Title></LinkContainer>
        <p>Form $12,999</p>
        <BasicRating/>
      </Card.Body>
    </Card>

      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.-eALR44ip3r7oVvZamHvaQHaHa?rs=1&pid=ImgDetMain" />
      <Card.Body>
     <LinkContainer to="/One plus 11R"><Card.Title>One plus 11R</Card.Title></LinkContainer> 
        <p>from $44,999</p> 
        <BasicRating/>
      </Card.Body>
    </Card>



    <Card style={{ width: '15rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.OoAfIyw8z2GSDSJJI4nGwgAAAA?rs=1&pid=ImgDetMain" />
      <Card.Body>
       <LinkContainer to="Vivo t2"><Card.Title>Vivo t2</Card.Title></LinkContainer> 
        <p>From $23,999</p>
        <BasicRating/>
      </Card.Body>
    </Card>


    <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.IEaqfoYdIryAE0dXFk9FFQHaHa?w=500&h=500&rs=1&pid=ImgDetMain" />
      <Card.Body>
       <LinkContainer to="/iPhone 14 pro "><Card.Title>iPhone 14 pro </Card.Title></LinkContainer> 
        <p>From $1,57,999</p>
        <BasicRating/>
      </Card.Body>
    </Card>

      


     
      

      <Card style={{ width: '18rem' }}>
      <Card.Img variant="top" src="https://th.bing.com/th/id/OIP.IEaqfoYdIryAE0dXFk9FFQHaHa?w=500&h=500&rs=1&pid=ImgDetMain" />
      <Card.Body>
        <Card.Title>Tecno pop 7 pro</Card.Title>
        <p>From $19,999</p>
        <BasicRating/>
      </Card.Body>
    </Card>
    

  
  
    {products.map(product => (
     

     <Card className='tag' key={product.id} style={{ width: '18rem' }}>
       <Card.Img variant="top" src={product.images[0]} />
       <Card.Body>
         <LinkContainer to={`/product/${product.id}`}>
           <Card.Title>{product.title}</Card.Title>
         </LinkContainer>
         <p>From ${product.price}</p>
        <BasicRating/>
       </Card.Body>
     </Card>
    
   ))}
   
   

      </div>
      </div>
     
    
    
    </>
  );
}

export default Cards2;