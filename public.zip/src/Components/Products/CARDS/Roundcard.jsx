import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import Image from 'react-bootstrap/Image';
import Row from 'react-bootstrap/Row';

function ShapeExample() {
  return (
    <div className="round1">
      <h3>Top Deals</h3>

    <Container>
      <Row className='round'>
       
      <Col xs={6} md={4}>
          <Image src="https://th.bing.com/th/id/OIP.RGhXRX912xVSfSUMgHxbuQAAAA?rs=1&pid=ImgDetMain" roundedCircle />
          <h4>Accessories</h4>
        </Col>

        <Col xs={6} md={4}>
          <Image src="https://th.bing.com/th/id/OIP.rHyHufgDrUXEBonuXZ9nmQHaGP?rs=1&pid=ImgDetMain" roundedCircle />
          <h1>Gadget</h1>
        </Col>

        

        <Col xs={6} md={4}>
          <Image src="https://th.bing.com/th/id/OIP.s4_O660Vah0Hx-Z_6Zct0wAAAA?rs=1&pid=ImgDetMain" roundedCircle />
          <h1>Rakhi special</h1>
        </Col>
        


        <Col xs={6} md={4}>
          <Image src="https://images.hindustantimes.com/img/2022/08/25/1600x900/pexels-antoni-shkraba-7081113_1661414759537_1661414794423_1661414794423.jpg" roundedCircle />
         <h1>Fashion</h1>
        </Col>
        


        <Col xs={6} md={4}>
          <Image src="https://th.bing.com/th/id/OIP.bHGYc7qodZ5ECP2Ms-mJgQHaEx?rs=1&pid=ImgDetMain" roundedCircle />
          <h1>Home essentials</h1>
        </Col>
        

        <Col xs={6} md={4}>
          <Image src="https://th.bing.com/th/id/OIP.sqr0SJvvbWScaVq2qk5CFQHaF9?rs=1&pid=ImgDetMain" roundedCircle />
          <h1>Furniture</h1>
        </Col>
        
        
      </Row>
    </Container>

    </div>
  );
}

export default ShapeExample;