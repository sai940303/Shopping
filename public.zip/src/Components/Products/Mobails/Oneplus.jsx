import React from 'react'
import StarIcon from '@mui/icons-material/Star';
import './Mobail.css';
import NavScrollExample from '../../header/Navbar';

const Oneplus = () => {
  return (
   <>
  <NavScrollExample/>
    <div className='mobail'>

        <div className='ONEPLUS 11R'>
          <div className="fixd">
            <img src="https://th.bing.com/th/id/OIP.-eALR44ip3r7oVvZamHvaQHaHa?rs=1&pid=ImgDetMain" alt="" />
         </div>

     <div className='details'>
     <h3>ONEPLUS 11R  (SKY blue 256 GB )   (12GB RAM)</h3>

     <div className="details2">
     <h4> 4.1  <StarIcon/></h4>
      <p>15,748 Rattings & 958 Reviews</p>
      </div>
      
      <div className="details3">
        <ul>
          <li>8 GB RAM | 256 GB ROM | Expandable Upto 2 T </li>
          <li>16.94 cm (6.67 inch) Full HD+ Display </li>
          <li>50MP + 2MP | 16MP Front Camera</li>
          <li> 5000 mAh Battery</li>
          <li>Dimensity 7050 Processor</li>
          <li>1 Year Manufacturer Warranty for Device and 6 Months Inbox Accessories</li>
        </ul>
      </div>

      <div className="price">
        <h1>$44,999</h1>
        <li><del>52,999</del> <span>22%</span> off </li>
        <li>Free delivery</li>
        <li className='saverdeal'>Saver Deal</li>
        <li>Upto 10,950 Off on Exchange</li>
      </div>


      <div className="btn">
     <button className='btn1'>Add to cart</button>
     <button className='btn2'>Buy Now</button>
     </div>


     </div>
     </div>
    </div>



    </>
  )
}

export default Oneplus;