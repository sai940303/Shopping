import React from 'react'
import StarIcon from '@mui/icons-material/Star';
import './Mobail.css';
import NavScrollExample from '../../header/Navbar';

const VivoT2 = () => {
  return (
   <>
  <NavScrollExample/>
    <div className='mobail'>

        <div className='oppo'>
          <div className="fixd">
            <img src="https://tunisiatech.tn/8882-large_default/smartphone-oppo-a17-4go-64go.jpg" alt="" />
         </div>

     <div className='details'>
     <h3>oppo A17  (Black 128GB )   (8GB RAM)</h3>

     <div className="details2">
     <h4> 4.1  <StarIcon/></h4>
      <p>11,748 Rattings & 658 Reviews</p>
      </div>
      
      <div className="details3">
        <ul>
          <li>8 GB RAM | 128 GB ROM | Expandable Upto 2 T </li>
          <li>16.94 cm (6.67 inch) Full HD+ Display </li>
          <li>50MP + 2MP | 16MP Front Camera</li>
          <li> 5000 mAh Battery</li>
          <li>Dimensity 7050 Processor</li>
          <li>1 Year Manufacturer Warranty for Device and 6 Months Inbox Accessories</li>
        </ul>
      </div>

      <div className="price">
        <h1>$16,999</h1>
        <li><del>21,999</del> <span>22%</span> off </li>
        <li>Free delivery</li>
        <li className='saverdeal'>Saver Deal</li>
        <li>Upto 10,950 Off on Exchange</li>
      </div>


      <div className="btn">
     <button className='btn1'>Add to cart</button>
     <button className='btn2'>Buy Now</button>
     </div>


     </div>
     </div>
    </div>



    </>
  )
}

export default VivoT2