import React from 'react'
import NavScrollExample from '../header/Navbar'

const Kidsfashion = () => {
  return (
    <div>
        <NavScrollExample/>
        Kidsfashion</div>
  )
}

export default Kidsfashion