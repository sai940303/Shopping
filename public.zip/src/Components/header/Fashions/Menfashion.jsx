import React from 'react'
import NavScrollExample from '../header/Navbar'

const Menfashion = () => {
  return (
    <div>
        <NavScrollExample/>
        Menfashion</div>
  )
}

export default Menfashion