import React from 'react'
import NavScrollExample from '../header/Navbar'

const Lediesfashion = () => {
  return (
    <div>
        <NavScrollExample/>
        Lediesfashion</div>
  )
}

export default Lediesfashion