import React, { useState, useEffect } from 'react';
import { Button } from 'react-bootstrap';
import NavScrollExample from '../header/Navbar';
import './Addcart.css';

const Cart = () => {
    const [cartItems, setCartItems] = useState([]);

    useEffect(() => {
        // Retrieve the cart items from localStorage
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        setCartItems(cart);
    }, []);

    const handleRemoveItem = (index) => {
        // Remove the item by its index
        const updatedCart = [...cartItems];
        updatedCart.splice(index, 1);
        setCartItems(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
    };

    // Calculate the total price of items in the cart, considering the quantity
    const totalPrice = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

    return (
        <div>
            <NavScrollExample />
            <div className="add-cart">
                {cartItems.length > 0 ? (
                    <>
                        {cartItems.map((item, index) => (
                            <div key={item.id} className="cart-item">
                                <img src={item.image} alt={item.name} />
                                <h5>{item.name}</h5>
                                <p>Product ID: {item.id}</p>
                                <p>Price: ${item.price.toFixed(2)}</p>
                                <p>Quantity: {item.quantity}</p> {/* Show the quantity here */}
                                <p>Total: ${(item.price * item.quantity).toFixed(2)}</p>
                                <Button variant="danger" onClick={() => handleRemoveItem(index)}>Remove</Button>
                            </div>
                        ))}
                        <div className="total-price">
                            <h4>Total Price: ${totalPrice.toFixed(2)}</h4>
                        </div>
                    </>
                ) : (
                    <p>Your cart is empty</p>
                )}
            </div>
        </div>
    );
};

export default Cart;
