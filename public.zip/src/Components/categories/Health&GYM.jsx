import React, { useEffect, useState } from 'react'
import { Card, Spinner } from 'react-bootstrap'
import BasicRating from '../Ratting'
import Footer from '../Footer/Footre'
import NavScrollExample from '../header/Navbar'


const Gym = () => {
 const [motor,setmotor] =useState([]);
 const [loading,setLoading] =useState([]);
 useEffect(()=>{
  fetch("https://fake-e-commerce-api.onrender.com/product/category/Health&GYM")
  .then(response=>response.json())
  .then(data=>{setmotor(data);console.log(data)
  setLoading(false)
  })
.catch(()=>setLoading(false))
 })
 const handleAddToCart = (product) => {
      
  const cart = JSON.parse(localStorage.getItem('cart')) || [];

  cart.push(product);

  console.log('Added to cart:', product);
};

  return ( 
    <div>
  <NavScrollExample/>
<div className="section4">      
    {loading ? (
                    <div className="spinner-container">
                        <Spinner animation="border" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </Spinner>
                    </div>
                ) :
    
    motor.map(product => (
      <div className="cat1">
         <Card key={product.id} style={{ width:  '18rem'}}>
         <Card.Img variant="top" src={product.image} alt={product.title} />
         <Card.Body>
           <Card.Title>{product.name}</Card.Title>
           <p>From ${product.price}</p>
            <BasicRating/>
            <button className='btn1' onClick={()=>handleAddToCart(product)}>Add to Cart</button>
      <button className='btn2'>Buy Now</button>
         </Card.Body>
       </Card>
       </div>
        ))}
        
       
  </div>
  <Footer/>
  
    </div>
  )
}

export default Gym