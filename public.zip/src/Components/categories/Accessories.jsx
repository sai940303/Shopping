import React, { useState, useEffect } from 'react';
import { Card, Spinner, Alert } from 'react-bootstrap';
import NavScrollExample from '../header/Navbar';
import BasicRating from '../Ratting';
import Footer from '../Footer/Footre';
import CheckIcon from'@mui/material/Alert';



const Accessories = () => {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showMessage, setShowMessage] = useState(false);

    useEffect(() => {
        fetch('https://fake-e-commerce-api.onrender.com/product/category/Accessories')
            .then(response => response.json())
            .then(data => {
                setProducts(data);
                setLoading(false); 
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                setLoading(false);
            });
    }, []);
    
    const addcart = (product) => {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
     
        cart.push(product);
        localStorage.setItem('cart', JSON.stringify(cart));
        console.log('Product added to cart:', product);

        // Show the "Add to cart successfully" message
        setShowMessage(true);

        // Temporarily remove this to check if the message shows up
         setTimeout(() => {
             setShowMessage(false);
         }, 3000);
    };

    return (
        <div>
            <NavScrollExample />
            {showMessage && (
               <Alert className='cart-alert' icon={<CheckIcon fontSize="inherit" />} severity="success">
              successfully   Add to cart
             </Alert>
            )}
            <div className="section4">
                {loading ? (
                    <div className="spinner-container">
                        <Spinner animation="border" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </Spinner>
                    </div>
                ) : (
                    products.map(product => (
                        <div className="cat1" key={product.id}>
                            <Card style={{ width: '18rem' }}>
                                <Card.Img variant="top" src={product.image} alt={product.title} />
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <p>From ${product.price}</p>
                                    <BasicRating />
                                    <button className='btn1' onClick={() => addcart(product)}>Add to Cart</button>
                                    <button className='btn2'>Buy Now</button>
                                </Card.Body>
                            </Card>
                        </div>
                    ))
                )}
            </div>

           
           

            <Footer />
        </div>
    );
};

export default Accessories;
