import React, { useEffect, useState } from 'react';
import { Alert, Card, Spinner } from 'react-bootstrap';
import BasicRating from '../Ratting';
import Footer from '../Footer/Footre';
import NavScrollExample from '../header/Navbar';
import CheckIcon from '@mui/icons-material/Check';

const Shoe = () => {
    const [shoe, setShoe] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showMessage, setShowMessage] = useState(false);

    useEffect(() => {
        fetch('https://fake-e-commerce-api.onrender.com/product/category/Shoes')
            .then(response => response.json())
            .then(data => {
                setShoe(data);
                setLoading(false);
                console.log(data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                setLoading(false);
            });
    }, []);
    const addcart = (product) => {
        // Retrieve the cart from localStorage or initialize it to an empty array
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
        // Find the product in the cart by its ID
        const productInCart = cart.find(item => item.id === product.id);
    
        if (productInCart) {
            productInCart.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }
    
       
        localStorage.setItem('cart', JSON.stringify(cart));
    
     
        setShowMessage(true);
    
      
        setTimeout(() => {
            setShowMessage(false);
        }, 3000);
    
        console.log('Product added to cart:', product);
    };
    
    
    return (
        <div>
            <NavScrollExample />
            {showMessage && (
                <Alert className='cart-alert' icon={<CheckIcon fontSize="inherit" />} severity="success">
                    Successfully added to cart
                </Alert>
            )}
            <div className="section4">
                {loading ? (
                    <div className="spinner-container">
                        <Spinner animation="border" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </Spinner>
                    </div>
                ) : (
                    shoe.map(product => (
                        <div key={product.id} className="cat1">
                            <Card style={{ width: '18rem' }}>
                                <Card.Img variant="top" src={product.image} alt={product.name} />
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <p>From ${product.price}</p>
                                    <BasicRating />
                                    <button 
                                        className='btn1' 
                                        onClick={() => addcart(product)}
                                    >
                                        Add to Cart
                                    </button>
                                    <button className='btn2'>Buy Now</button>
                                </Card.Body>
                            </Card>
                        </div>
                    ))
                )}
            </div>
            <Footer />
        </div>
    );
}

export default Shoe;