import { Card, Spinner, Alert } from 'react-bootstrap';
import React, { useState, useEffect } from 'react';
import NavScrollExample from '../header/Navbar';
import BasicRating from '../Ratting';
import Footer from '../Footer/Footre';
import CheckIcon from '@mui/icons-material/Check';

const Allcategories = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showMessage, setShowMessage] = useState(false);

  useEffect(() => {
    fetch('https://fake-e-commerce-api.onrender.com/product')
      .then(response => response.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const addcart = (product) => {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Check if the product already exists in the cart
    const existingProduct = cart.find(item => item.id === product.id);
    if (existingProduct) {
      // If the product exists, increase its quantity
      existingProduct.quantity += 1;
    } else {
      // If the product does not exist, add it with quantity 1
      cart.push({ ...product, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    console.log('Product added to cart:', product);

    
    setShowMessage(true);

   
    setTimeout(() => {
      setShowMessage(false);
    }, 3000);
  };

  return (
    <div>
      {showMessage && (
        <Alert className='cart-alert' icon={<CheckIcon fontSize="inherit" />} severity="success">
          Successfully added to cart
        </Alert>
      )}
      <NavScrollExample />

      <div className="section4">
        {loading ? (
          <div className="spinner-container">
            <Spinner animation="border" role="status" />
          </div>
        ) : (
          products.map(product => (
            <div className="cat1" key={product.id}>
              <Card style={{ width: '18rem' }}>
                <Card.Img variant="top" src={product.image} alt={product.title} />
                <Card.Body>
                  <Card.Title>{product.name}</Card.Title>
                  <p>From ${product.price}</p>
                  <BasicRating />
                  <button className='btn1' onClick={() => addcart(product)}>Add to Cart</button>
                  <button className='btn2'>Buy Now</button>
                </Card.Body>
              </Card>
            </div>
          ))
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Allcategories;
