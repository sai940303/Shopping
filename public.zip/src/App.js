import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Allcategories from './Components/All categories/Allcategories';


import Mainpage from './Components/Mainpage';
import Oppoa17 from './Components/Products/Mobails/Oppoa17';
import Oneplus from './Components/Products/Mobails/Oneplus';
import Iphone from './Components/Products/Mobails/Iphone14';
import VivoT2 from './Components/Products/Mobails/VivoT2';


import Tv from './Components/categories/Tv';
import Watches from './Components/categories/watche';
import Motors from './Components/categories/Motors';


import Accessories from './Components/categories/Accessories';
import Shoe from './Components/categories/Shoe';
import Mobile from './Components/categories/Mobile';
import Gym from './Components/categories/Health&GYM';
import Cameras from './Components/categories/Camera';
import Cart from './Components/add to cart/Cart';

import LoginPage from './Components/Login/Login';







function App() {
  return (
    <div className="App">
      
      <BrowserRouter>
      <Routes>
      <Route path="/" element={<Mainpage />} />
      <Route path="/Allcategories" element={<Allcategories />} />
      <Route path='Accessories' element={<Accessories/>} />
      <Route path='shoes' element={<Shoe/>} />
      <Route path='tv' element={<Tv/>} />
      <Route path='watches' element={<Watches/>} />
      <Route path='parts' element={<Motors/>} />
      <Route path='Mobiles' element={<Mobile/>} />
      <Route path='Gym' element={<Gym/>} />
      <Route path='camera' element={<Cameras/>} />
      <Route path='add to cart' element={<Cart/>} />
      <Route path='Login' element={<LoginPage/>} />
   
      
      
      
      </Routes>
      
      </BrowserRouter>

      <BrowserRouter>
     <Routes>

     <Route path="/oppo A17"  element={<Oppoa17/>} />
     <Route path='One plus 11R' element={<Oneplus/>} />
     <Route path='iPhone 14 pro max' element={<Iphone/>} />
     <Route path='Vivo T2' element={<VivoT2/>} />
   
     
     </Routes>
      </BrowserRouter>

      
      
      
    </div>
  );
}

export default App;
